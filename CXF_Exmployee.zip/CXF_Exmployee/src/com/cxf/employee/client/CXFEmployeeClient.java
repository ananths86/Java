package com.cxf.employee.client;

import java.net.MalformedURLException;

import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

import com.cxf.employee.model.Employee;
import com.cxf.employee.service.CXFEmployeeService;

public class CXFEmployeeClient {

	public static void main(String[] args) throws MalformedURLException {
		String serviceURL = "http://localhost:8080/CXF_Exmployee/changeEmployee?wsdl";

		/*
		 * URL wsdlUrl = new URL(serviceURL); QName SERVICE_NAME = new
		 * QName("http://localhost:8080/CXF_Exmployee/changeEmployee",
		 * "SOAPService"); Service service = Service.create(wsdlUrl,
		 * SERVICE_NAME); service.getPort(CXFEmployeeServiceImpl.class);
		 */
		JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
		factory.setServiceClass(CXFEmployeeService.class);
		factory.setAddress(serviceURL);
		factory.getInInterceptors().add(new LoggingInInterceptor());
		factory.getOutInterceptors().add(new LoggingOutInterceptor());
		CXFEmployeeService cxfEmployeeService = (CXFEmployeeService) factory
				.create();

		Employee employee = new Employee();
		employee.setEmpId(378235);
		employee.setName("Ananth");
		employee.setDesignation("A");

		cxfEmployeeService.changeEmployeeDetail(employee);
	}

}

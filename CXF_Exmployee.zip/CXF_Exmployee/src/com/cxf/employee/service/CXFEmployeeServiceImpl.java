package com.cxf.employee.service;

import javax.jws.WebService;

import com.cxf.employee.model.Employee;

@WebService(endpointInterface="com.cxf.employee.service.CXFEmployeeService")
public class CXFEmployeeServiceImpl implements CXFEmployeeService {
	
	@Override
	public Employee changeEmployeeDetail(Employee employee) {
		if (employee != null) {
			employee.setName("Hello" + employee.getName());
		}
		return employee;
	}

}

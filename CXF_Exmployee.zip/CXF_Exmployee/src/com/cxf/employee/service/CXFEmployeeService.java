package com.cxf.employee.service;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.cxf.employee.model.Employee;

@WebService
@SOAPBinding(style=Style.DOCUMENT)
public interface CXFEmployeeService {
	
	@WebMethod
	public Employee changeEmployeeDetail(Employee employee);

}

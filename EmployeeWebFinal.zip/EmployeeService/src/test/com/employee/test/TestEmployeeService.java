package com.employee.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.employee.service.EmployeeManager;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/conf/employee/employeeCtx.xml"})
public class TestEmployeeService {

	@Autowired
	private EmployeeManager employeeManager;
	
	@Test
	public void testGetAllEmployees() {
		employeeManager.listAllEmployees();
	}
}

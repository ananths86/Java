package com.employee.service;

import java.util.List;

import com.employee.model.Employee;

public interface EmployeeManager {

	public List<Employee> listAllEmployees();
}

package com.employee.service;

import java.util.List;

import com.employee.dao.EmployeeDAO;
import com.employee.model.Employee;

public class EmployeeManagerImpl implements EmployeeManager {

	private EmployeeDAO employeeDAO;
	
	@Override
	public List<Employee> listAllEmployees() {
		
		return employeeDAO.listAllEmployees();
	}

	/**
	 * @param employeeDAO the employeeDAO to set
	 */
	public void setEmployeeDAO(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	
	
	
}

package com.employee.dao;

import java.util.List;

import com.employee.excel.EmployeeDB;
import com.employee.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	private EmployeeDB employeeDB;
	
	
	@Override
	public void addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Employee> listAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDB.getAllEmployees();
	}

	/**
	 * @param employeeDB the employeeDB to set
	 */
	public void setEmployeeDB(EmployeeDB employeeDB) {
		this.employeeDB = employeeDB;
	}
	
	
	

}

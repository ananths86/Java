/**
 * 
 */
package com.employee.excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.util.StringUtils;

import com.employee.model.Employee;
import com.employee.vo.EmployeeVO;

/**
 * @author 378235
 *
 */

public class EmployeeDB {
	
	private void createEmployeeExcelFile() {
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Employee sheet");
		try {
		    FileOutputStream out = 
		            new FileOutputStream(new File("Employee.xls"));
		    workbook.write(out);
		    out.close();
		    System.out.println("Excel written successfully..");
		     
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}
	
	private Employee getEmployeeDetail(String empId) {
		return null;
	}
	
	public List<Employee> getAllEmployees() {
		return populateEmployeeDetails(readExcel());
	}
	
	private List<Employee> populateEmployeeDetails(List<EmployeeVO> employeeVOList) {
		
		List<EmployeeVO> employeeVOs = employeeVOList;
		List<Employee> employeeList = new ArrayList<Employee>();
		if (employeeVOs != null && !employeeVOs.isEmpty()) {
			for (EmployeeVO employeeVO : employeeVOs) {
				Employee employee = new Employee();
				employee.setEmployeeId(employeeVO.getEmployeeId());
				employee.setEmployeeName(employeeVO.getEmployeeName());
				employee.setDesignation(employeeVO.getDesignation());
				employeeList.add(employee);
			}
		}
		return employeeList;
	}

	public static void main(String[] args) {
		EmployeeDB empDb = new EmployeeDB();
		System.out.print(empDb.isFileFound());
	}
	
	
	private List<EmployeeVO> readExcel() {
		
		List<EmployeeVO> employeeVOList = new ArrayList<EmployeeVO>();
		try {
			FileInputStream file = new FileInputStream(new File("D:\\workspace\\EmployeeWeb\\Employee.xls"));
		     
		    //Get the workbook instance for XLS file 
		    HSSFWorkbook workbook = new HSSFWorkbook(file);
		 
		    //Get first sheet from the workbook
		    HSSFSheet sheet = workbook.getSheetAt(0);
		    
		    Iterator<Row> rowIterator = sheet.iterator();
		   
		    EmployeeVO employeeVO = null; 
		    while(rowIterator.hasNext()) {
		        Row row = rowIterator.next();
		         if (row.getRowNum() == 0) {
		        	 continue;
		         }
		        //For each row, iterate through each columns
		        Iterator<Cell> cellIterator = row.cellIterator();
		        String finalCellValue = null;
		        employeeVO = new EmployeeVO(); 
		        while(cellIterator.hasNext()) {
		        	String cellValue = null;
		            Cell cell = cellIterator.next();
		             
		            switch(cell.getCellType()) {
		                case Cell.CELL_TYPE_BOOLEAN:
		                    System.out.print(cell.getBooleanCellValue() + "\t\t");
		                    break;
		                case Cell.CELL_TYPE_NUMERIC:
		                    System.out.print(cell.getNumericCellValue() + "\t\t");
		                    cellValue = String.valueOf(cell.getNumericCellValue());
		                    break;
		                case Cell.CELL_TYPE_STRING:
		                    System.out.print(cell.getStringCellValue() + "\t\t");
		                    cellValue = cell.getStringCellValue();
		                    break;
		            }
		            finalCellValue = ((finalCellValue != null) ? finalCellValue + "|" + cellValue : cellValue); 
		        }
		        employeeVO = createEmployeeVO(finalCellValue);
		        employeeVOList.add(employeeVO);
		        //System.out.println("");
		    }
		    
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		 return employeeVOList;
	}
	
	private EmployeeVO writeToExcel(Employee employee) {
		
		HSSFWorkbook workbook = null;
		HSSFSheet sheet = null;
		try {
			if (isFileFound()) {
				FileInputStream file = new FileInputStream(new File("Employee.xls"));
			     
			    //Get the workbook instance for XLS file 
			    workbook = new HSSFWorkbook(file);
			 
			    //Get first sheet from the workbook
			    sheet = workbook.getSheetAt(0);
			} else {
				workbook = new HSSFWorkbook();
				sheet = workbook.createSheet("Employee.xls");
			}
			 
			Map<String, Object[]> data = new HashMap<String, Object[]>();
			data.put("1", new Object[] {"Emp No.", "Name", "Salary"});
			data.put("2", new Object[] {1d, "John", 1500000d});
			data.put("3", new Object[] {2d, "Sam", 800000d});
			data.put("4", new Object[] {3d, "Dean", 700000d});
			 
			Set<String> keyset = data.keySet();
			int rownum = 0;
			for (String key : keyset) {
			    Row row = sheet.createRow(rownum++);
			    Object [] objArr = data.get(key);
			    int cellnum = 0;
			    for (Object obj : objArr) {
			        Cell cell = row.createCell(cellnum++);
			        if(obj instanceof Date) 
			            cell.setCellValue((Date)obj);
			        else if(obj instanceof Boolean)
			            cell.setCellValue((Boolean)obj);
			        else if(obj instanceof String)
			            cell.setCellValue((String)obj);
			        else if(obj instanceof Double)
			            cell.setCellValue((Double)obj);
			    }
			}
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		}
		return null;
	}

	private EmployeeVO createEmployeeVO(String finalCellValue) {
		
		EmployeeVO employeeVO = new EmployeeVO();
		if (!StringUtils.isEmpty(finalCellValue)) {
			StringTokenizer tokens = new StringTokenizer(finalCellValue, "|");
			int count = 0;
			for (int i=0; i <= (tokens.countTokens() +1); i++) {
				String token = tokens.nextToken();
				if (count == 0) {
					employeeVO.setEmployeeId(token);
				} else if (count == 1) {
					employeeVO.setEmployeeName(token);
				} else if (count == 2) {
					employeeVO.setDesignation(token);
				}
				count ++;
			}
		}
		return employeeVO;
		
	}	

	private boolean isFileFound() {
		FileInputStream file;
		try {
			file = new FileInputStream(new File("Employee.xls"));
			if (file != null) {
				return true;
			}
		} catch (FileNotFoundException e) {
			return false;
		}
		
		return false;
	}
	
	
}

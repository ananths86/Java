package com.employee.json.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.employee.model.Employee;
import com.employee.service.EmployeeManager;

@Controller
public class EmployeeJSONController {

	@Autowired
	private EmployeeManager employeeManager;
	
	
	/**
	 * @param employeeManager the employeeManager to set
	 */
	public void setEmployeeManager(EmployeeManager employeeManager) {
		this.employeeManager = employeeManager;
	}


	@RequestMapping(value="/getAllEmployees",method=RequestMethod.GET)
	public @ResponseBody List<Employee> findAll() {
		return employeeManager.listAllEmployees();
	}
}

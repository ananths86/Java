package com.employee.prsn;

import java.util.List;

import com.employee.model.Employee;


public interface EmployeePresentation {

	public List<Employee> listEmployees();
}

package com.employee.prsn;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.employee.model.Employee;
import com.employee.service.EmployeeManager;

public class EmployeePresentationImpl implements EmployeePresentation {

	@Autowired
	private EmployeeManager employeeManager;
	@Override
	public List<Employee> listEmployees() {
		return employeeManager.listAllEmployees();
	}
	/**
	 * @param employeeManager the employeeManager to set
	 */
	public void setEmployeeManager(EmployeeManager employeeManager) {
		this.employeeManager = employeeManager;
	}
	
	

}

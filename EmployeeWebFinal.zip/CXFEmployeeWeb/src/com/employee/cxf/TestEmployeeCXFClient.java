package com.employee.cxf;

import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

import com.employee.model.Employee;

public class TestEmployeeCXFClient {
	
	public static void main(String args[]) throws Exception {

	     JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();

	      factory.setServiceClass(EmployeeCXFWeb.class);
	      factory.setAddress("http://localhost:8080/CXFEmployeeWeb/employee?wsdl");
	      factory.getInInterceptors().add(new LoggingInInterceptor());
	      factory.getOutInterceptors().add(new LoggingOutInterceptor());
	      EmployeeCXFWeb client = (EmployeeCXFWeb) factory.create();
	      for(Employee employee : client.getAllEmployees()) {
	    	  System.out.println("EmployeeDetails : " + employee.toString());
	      }
	      System.exit(0);
		
		/*ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new  String[] {"conf/employee/cxf/employee-cxf-client.xml"});
        EmployeeCXFWeb client = (EmployeeCXFWeb) context.getBean("client");
        List<Employee> employees = client.getAllEmployees();
        for(Employee employee : employees) {
	    	  System.out.println("EmployeeDetails : " + employee.toString());
	      }*/

	    }


}

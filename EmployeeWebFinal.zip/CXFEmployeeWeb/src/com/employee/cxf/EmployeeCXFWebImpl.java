package com.employee.cxf;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.employee.model.Employee;
import com.employee.prsn.EmployeePresentation;

@WebService(endpointInterface = "com.employee.cxf.EmployeeCXFWeb")
public class EmployeeCXFWebImpl extends SpringBeanAutowiringSupport implements EmployeeCXFWeb{

	
	@Autowired
	private EmployeePresentation employeePrsn;
	
	@WebMethod
	public List<Employee> getAllEmployees() {
		
		return employeePrsn.listEmployees();
	}

	/**
	 * @param employeePrsn the employeePrsn to set
	 */
	public void setEmployeePrsn(EmployeePresentation employeePrsn) {
		this.employeePrsn = employeePrsn;
	}

	
}

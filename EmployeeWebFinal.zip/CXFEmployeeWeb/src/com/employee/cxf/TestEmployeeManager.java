package com.employee.cxf;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.employee.prsn.EmployeePresentation;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:/conf/employee/cxf/employee-cxf-ctx.xml"})
public class TestEmployeeManager {

	@Autowired
	private EmployeePresentation employeePrsn;
	
	@Test
	public void testGetAllEmployees() {
		employeePrsn.listEmployees();
	}
	
}

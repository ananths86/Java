package com.employee.cxf;

import java.util.List;

import javax.jws.WebService;

import com.employee.model.Employee;

@WebService
public interface EmployeeCXFWeb {

	public List<Employee> getAllEmployees();
}

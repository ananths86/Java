package com.jquery.model;

import java.util.ArrayList;
import java.util.List;



public class EmployeeServiceImpl {

	public Employee getEmployee() {
		
		Employee employee = new Employee();
		employee.setEmployeeId(378235);
		employee.setEmployeeName("Ananth");
		employee.setDesignation("Perumbakkam");
		return employee;
	}
	
	public List<Employee> getAllEmployees() {
		return getAllEmployees();
	}
	
	private List<Employee> getEmployees() {

		List<Employee> employeeList = new ArrayList<Employee>();

		Employee employee = new Employee();
		employee.setEmployeeId(378235);
		employee.setEmployeeName("Ananth");
		employee.setDesignation("Perumbakkam");
		
		Employee employee1 = new Employee();
		employee1.setEmployeeId(378236);
		employee1.setEmployeeName("Suresh");
		employee1.setDesignation("Bangalore");

		employeeList.add(employee);

		return employeeList;

	}
}

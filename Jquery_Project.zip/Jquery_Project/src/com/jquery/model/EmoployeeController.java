package com.jquery.model;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class EmoployeeController {
	
	EmployeeServiceImpl empService = new EmployeeServiceImpl();

	@RequestMapping(value="/getEmployee/{empId}", method=RequestMethod.GET,headers="Accept=application/json")
	public Employee getEmployee(@PathVariable int empId) {
		
		return empService.getEmployee();
	}
	
	@RequestMapping(value="/getAllEmployees", method=RequestMethod.GET,headers="Accept=application/json")
	public List<Employee> getAllEmployees() {
		
		return empService.getAllEmployees();
		
	}
	
}

package com.spring.batch.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Employee")
public class Employee {
	
	private int employeeId;
	private String fName;
	private String lName;
	private String designation;
	public int getEmployeeId() {
		return employeeId;
	}
	@XmlElement(name="EmployeeId")
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getfName() {
		return fName;
	}
	
	@XmlElement(name="FirstName")
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	
	@XmlElement(name="Last Name")
	public void setlName(String lName) {
		this.lName = lName;
	}
	
	public String getDesignation() {
		return designation;
	}
	
	@XmlElement(name="Designation")
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	
	

}

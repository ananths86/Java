package com.spring.batch.reader;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.spring.batch.model.Employee;

public class EmployeeFieldMapper implements FieldSetMapper<Employee>{

	@Override
	public Employee mapFieldSet(FieldSet fieldSet) throws BindException {
		Employee employee = new Employee();
		employee.setEmployeeId((Integer.parseInt(fieldSet.readString(0))));
		employee.setfName(fieldSet.readString(1));
		employee.setlName(fieldSet.readString(2));
		employee.setDesignation(fieldSet.readString(3));
		return employee;
	}

}

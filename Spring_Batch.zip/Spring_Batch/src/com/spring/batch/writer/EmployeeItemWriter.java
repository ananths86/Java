package com.spring.batch.writer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;

import com.spring.batch.model.Employee;

public class EmployeeItemWriter implements ItemWriter<Employee> {

	private final String FILE_NAME = "EmployeeBatch";

	private File file;

	private static final String[] HEADERS = { "S.No", "Employee Id",
			"Employee First Name", "Employee Last Name", "Employee Designation" };

	private String outputFilename;
	private Workbook workbook;
	private CellStyle dataCellStyle;
	private int currRow = 0;

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {

		outputFilename = FILE_NAME + "_" + System.currentTimeMillis() + ".xlsx";
		file = new File(FILE_NAME + "_" + System.currentTimeMillis() + ".xlsx");

		// Get the workbook instance for XLS file
		workbook = new HSSFWorkbook();

		Sheet sheet = workbook.createSheet("Employee");

		currRow++;
		addHeaders(sheet);
		initDataStyle();

	}

	@AfterStep
	public void afterStep(StepExecution stepExecution) throws IOException {
		FileOutputStream fos = new FileOutputStream(outputFilename);
		workbook.write(fos);
		fos.close();
	}

	@Override
	public void write(List<? extends Employee> employees) throws Exception {
		Sheet sheet = workbook.getSheetAt(0);

		Employee[] employeesArray = employees.toArray(new Employee[employees.size()]);
		for (int i = 0; i < employeesArray.length; i++) {
			currRow++;
			Row row = sheet.createRow(currRow);
			createStringCell(row, String.valueOf(employeesArray[i].getEmployeeId()), 0);
			createStringCell(row, employeesArray[i].getfName(), 1);
			createStringCell(row, employeesArray[i].getlName(), 2);
			createStringCell(row, employeesArray[i].getDesignation(), 3);
		}
	}

	private void createStringCell(Row row, String val, int col) {
		Cell cell = row.createCell(col);
		cell.setCellType(Cell.CELL_TYPE_STRING);
		cell.setCellValue(val);
	}

	private void createNumericCell(Row row, Double val, int col) {
		Cell cell = row.createCell(col);
		cell.setCellType(Cell.CELL_TYPE_NUMERIC);
		cell.setCellValue(val);
	}

	private void addHeaders(Sheet sheet) {

		Workbook wb = sheet.getWorkbook();

		CellStyle style = wb.createCellStyle();
		Font font = wb.createFont();

		font.setFontHeightInPoints((short) 10);
		font.setFontName("Arial");
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		style.setAlignment(CellStyle.ALIGN_CENTER);
		style.setFont(font);

		Row row = sheet.createRow(2);
		int col = 0;

		for (String header : HEADERS) {
			Cell cell = row.createCell(col);
			cell.setCellValue(header);
			cell.setCellStyle(style);
			col++;
		}
		currRow++;
	}

	private void initDataStyle() {
		dataCellStyle = workbook.createCellStyle();
		Font font = workbook.createFont();

		font.setFontHeightInPoints((short) 10);
		font.setFontName("Arial");
		dataCellStyle.setAlignment(CellStyle.ALIGN_LEFT);
		dataCellStyle.setFont(font);
	}

}
